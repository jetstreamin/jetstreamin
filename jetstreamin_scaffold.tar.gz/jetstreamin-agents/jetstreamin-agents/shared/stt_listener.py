# stub for speech-to-text
class STTListener:
    def listen(self):
        # Placeholder: capture mic input, run whisper.cpp or vosk
        return input("You> ")
